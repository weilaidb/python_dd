#Filename:var.py
i=5
print i
i = i + 1
print i
s = '''This is a multi-line string.
This is the second line.'''
print s

t = 'This is a stirng.\
This continues the string.'
print t

