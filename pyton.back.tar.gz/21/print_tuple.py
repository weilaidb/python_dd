#!/usr/bin/python
#Filename:print_tuple.py
age = 22
name = 'Swrapoop'
print '%s is %d years old' % (name,age)
print 'Why is %s playing with that python ?' % name
