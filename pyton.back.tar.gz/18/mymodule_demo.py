#!/usr/bin/python
#Filename:mymodule_demo.py
import mymodule
mymodule.sayHi()
print 'Version',mymodule.version
