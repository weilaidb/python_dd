#!/usr/bin/python
#Filename:mymodule_demo2.py
from mymodule import sayHi,version
#Alternative:
#from mymodule import *
sayHi()
print 'Vesion',version
