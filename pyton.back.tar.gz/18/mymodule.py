#!/usr/bin/python
#Filename:mymodule.py
def sayHi():
	print 'Hi, this is mymodule speaking.'

version = '0.1'
#End of mymodule.py
