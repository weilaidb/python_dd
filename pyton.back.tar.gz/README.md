# python_dd
python daily development
