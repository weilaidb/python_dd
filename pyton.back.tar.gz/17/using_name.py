#!/usr/bin/python
#Filename:using_name.py
if __name__ == '__main__':
	print 'This program is being run by itself'
else:
	print 'I am being imported from another module'

print '__name is__',__name__
